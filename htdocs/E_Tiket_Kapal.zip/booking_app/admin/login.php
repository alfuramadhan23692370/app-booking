<?php
// login.php - Halaman untuk proses login pengguna

// Mulai sesi di awal setiap halaman yang menggunakan sesi
session_start();

// Jika pengguna sudah login, arahkan ke dashboard
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header("Location: dashboard.php"); // Ganti 'dashboard.php' jika halaman tujuan Anda berbeda
    exit;
}

// Inisialisasi variabel untuk pesan error login
$login_err = "";

// Proses formulir jika ada data POST (saat tombol Login diklik)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // --- Bagian Verifikasi Kredensial ---
    // PENTING: Untuk contoh ini, username dan password di-hardcode.
    // DALAM APLIKASI PRODUKSI, JANGAN PERNAH MENGGUNAKAN INI!
    // Anda harus memverifikasi username dan password dari database menggunakan
    // password_hash() untuk menyimpan password terenkripsi dan password_verify() untuk membandingkannya.
    $valid_username = "admin"; // Username contoh
    $valid_password = "admin123"; // Password contoh

    // Ambil input dari formulir dan hapus spasi berlebih
    $username_input = trim($_POST["username"]);
    $password_input = trim($_POST["password"]);

    // Verifikasi kredensial
    if ($username_input === $valid_username && $password_input === $valid_password) {
        // Login berhasil
        $_SESSION['loggedin'] = true; // Tandai pengguna sudah login
        $_SESSION['username'] = $username_input; // Simpan username di sesi

        // Arahkan ke halaman dashboard
        header("Location: dashboard.php");
        exit; // Penting: hentikan eksekusi skrip
    } else {
        // Login gagal
        $login_err = "Username atau password salah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Aplikasi Booking</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .login-container { background-color: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); width: 300px; text-align: center; }
        h2 { color: #333; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; text-align: left; }
        label { display: block; margin-bottom: 5px; color: #555; }
        input[type="text"], input[type="password"] { width: calc(100% - 20px); padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
        input[type="submit"] { background-color: #007bff; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; width: 100%; }
        input[type="submit"]:hover { background-color: #0056b3; }
        .error-message { color: red; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php 
        if(!empty($login_err)){
            echo '<p class="error-message">' . $login_err . '</p>';
        }        
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <input type="submit" value="Login">
            </div>
        </form>
    </div>
</body>
</html>