<?php
// logout.php - Proses logout pengguna

// Mulai sesi
session_start();

// Hancurkan semua variabel sesi.
$_SESSION = array();

// Jika menggunakan cookie sesi, hapus juga cookie tersebut.
// Ini memastikan sesi benar-benar bersih dari browser pengguna.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Terakhir, hancurkan sesi di server.
session_destroy();

// Arahkan pengguna ke halaman login
header("Location: login.php"); // Ganti 'login.php' jika lokasi file login Anda berbeda
exit; // Pastikan tidak ada kode yang dieksekusi setelah pengalihan
?>